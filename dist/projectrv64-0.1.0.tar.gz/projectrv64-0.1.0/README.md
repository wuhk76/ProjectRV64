# ProjectRV64
RISC-V RV64 emulator written in Python.

## Usage
This is a Python module that emulates a basic 64-bit RISC-V CPU. It can execute RISC-V assembly code from either a file or a list of instructions and store the results in memory and registers.

Using PyPy3 on a mid-tier Intel Core i3 processor, the emulator can execute approximately 1 million instructions per second.

The module can be imported with the following lines:

```python
from projectrv64 import RV64

# Create 16 MB of memory
cpu = RV64(16 * 1048576)
```

The `projectrv64.py` module must be located in the same directory as the Python script.

Using PyPy instead of the standard Python interpreter may increase execution speed by approximately 2–4 times. PyPy can be downloaded from:

https://pypy.org/download.html

The package can also be installed from the wheel file with the following command:

```bash
pip install dist/projectrv64-0.1.0-py3-none-any.whl
```

## Variables

### Registers
The registers are stored in `cpu.registers` as a dictionary. The dictionary keys use RISC-V register alias names such as `a0`, `sp`, and `ra`.

A register value can be accessed with the following line:

```python
some_variable = cpu.registers["register_name"]
```

The value of a register can be changed with:

```python
cpu.registers["register_name"] = some_value
```

Here, `"register_name"` is the alias name of the register. Although the register dictionary uses alias names, names such as `x10` can also be used in the assembly code.

Registers are cleared by default before each new execution.

### Memory
Memory is stored in `cpu.mem` as a `bytearray`.

```python
some_byte = cpu.mem[address]
```

Memory is cleared by default before each new execution unless memory is provided using the `mem` argument.

## Functions

### Execute

```python
cpu.execute(asm, pc = 0, mem = None, imax = 0, debug = False)
```

This function executes RISC-V assembly code. The `asm` argument can be either a file path or a list of assembly instructions.

The `pc` option controls the initial program counter and determines where execution begins.

The `mem` option allows existing memory data to be loaded before execution.

The `imax` option controls the maximum number of instructions that can be executed. A value of `0` disables the instruction limit.

If `debug` is set to `True`, the emulator prints each instruction as it is executed.

Example:

```python
from projectrv64 import RV64

cpu = RV64(16 * 1048576)
cpu.execute("main.asm", pc = 0, imax = 0, debug = False)

print(cpu.registers["a0"])
```
